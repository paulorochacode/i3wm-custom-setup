import tkinter as tk
import os
import sys

os.system('firewall-cmd --state > firewalldstatus')
os.system('sudo ufw status verbose | egrep Default > ufwstatus')
os.system('sudo ufw status verbose | egrep IN > ufwstatusopen')

f = open("ufwstatus", "r")
firewalldstatus = f.read()

f = open("ufwstatusopen", "r")
ufwstatusopen = f.read()

f = open("firewalldstatus", "r")
ufwstatus = f.read()

#if ufwstatus == None or 0 or "" :
#        os.system('sudo ufw status > ufwstatus ')
#        f = open("ufwstatus", "r")
#        ufwstatus = f.read()
#        message4 = tk.Label(root, text="ufw status :" + ufwstatus)


root = tk.Tk()


# place a label on the root window
message1 = tk.Label(root, text="firewalld status :" + firewalldstatus)
message2 = tk.Label(root, text="ufw status :" + ufwstatus)
message3 = tk.Label(root, text="ufw open doors :" + ufwstatusopen)

message1.pack()
message2.pack()
message3.pack()
#message4.pack()
# keep the window displaying
root.mainloop()

os.system('sudo rm -rf firewalldstatus')
os.system('sudo rm -rf ufwstatus')
os.system('sudo rm -rf ufwstatusopen')
