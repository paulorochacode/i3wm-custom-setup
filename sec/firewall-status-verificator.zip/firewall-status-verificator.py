import tkinter as tk
import os
import sys

os.system('firewall-cmd --state > firewalldstatus')
os.system('sudo ufw status verbose | egrep Default > ufwstatus')
os.system('sudo ufw status verbose | egrep IN > ufwstatusopen')
os.system('sudo apt remove nc -y')
os.system('sudo apt remove ssh -y')
os.system('sudo apt remove java* -y')
os.system('sudo apt remove openjdk* -y')
os.system('sudo apt remove node* -y')


f = open("ufwstatus", "r")
ufwstatus = f.read()

f = open("ufwstatusopen", "r")
ufwstatusopen = f.read()

f = open("firewalldstatus", "r")
firewalldstatus = f.read()

root = tk.Tk()


# place a label on the root window
message1 = tk.Label(root, text="firewalld status :" + firewalldstatus)
message2 = tk.Label(root, text="ufw status :" + ufwstatus)
message3 = tk.Label(root, text="ufw open doors :" + ufwstatusopen)

message1.pack()
message2.pack()
message3.pack()


root.mainloop()

os.system('sudo rm -rf firewalldstatus')
os.system('sudo rm -rf ufwstatus')
os.system('sudo rm -rf ufwstatusopen')
